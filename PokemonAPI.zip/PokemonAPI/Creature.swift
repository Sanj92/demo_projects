//
//  Creature.swift
//  PokemonAPI
//
//  Created by Tushar Patil on 22/05/24.
//

import Foundation

struct Creature: Codable, Identifiable {
    let  id = UUID().uuidString
    var name: String
    var url: String // url for detial on pokemon
    
    enum CodingKeys: CodingKey {
        case name, url
        
    }
    
}

