import SwiftUI

struct CreaturesListView: View {
    
    @StateObject var creaturesVM = CreaturesViewModel()
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                List(searchResults) { creature in
                    LazyVStack {
                        NavigationLink {
                            DetailView(creature: creature)
                        } label: {
                            CreatureCardView(creature: creature)
                        }
                    }
                    .onAppear {
                        Task {
                            await creaturesVM.loadNextIfNeeded(creature: creature)
                        }
                    }
                }
                .listStyle(.plain)
                .navigationTitle("Pokemon")
                .toolbar {
                    ToolbarItem(placement: .bottomBar) {
                        Button("Load All") {
                            Task {
                                await creaturesVM.loadAll()
                            }
                        }
                    }
                    
                    ToolbarItem(placement: .status) {
                        Text("\(creaturesVM.creaturesArray.count) of \(creaturesVM.count) pokemon's")
                    }
                }
                .searchable(text: $searchText)
                
                if creaturesVM.isLoading {
                    ProgressView()
                        .tint(.blue)
                        
                }
            }
        }
        .task {
            await creaturesVM.getData()
        }
    }
    
    var searchResults: [Creature] {
        if searchText.isEmpty {
            return creaturesVM.creaturesArray
        } else {
            return creaturesVM.creaturesArray.filter { $0.name.capitalized.contains(searchText) }
        }
    }
}

struct CreatureCardView: View {
    var creature: Creature
    @State private var animateCard = false
    
    var body: some View {
        ZStack {
            VStack(alignment: .leading, spacing: 8) {
                Text(creature.name.capitalized)
                    .font(.title2)
                    .bold()
                    .padding(.leading)
                
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
            .shadow(radius: 8, x: 5, y: 5)
            .scaleEffect(animateCard ? 1.0 : 0.8)
            .opacity(animateCard ? 1.0 : 0.0)
            .animation(.easeIn(duration: 0.5), value: animateCard)
            .onAppear {
                animateCard = true
            }
        }
        .padding(.vertical, 4)
    }
}

struct CreaturesListView_Previews: PreviewProvider {
    static var previews: some View {
        CreaturesListView()
    }
}
