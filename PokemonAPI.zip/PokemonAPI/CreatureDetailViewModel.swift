//
//  CreaturesViewModel.swift
//  PokemonAPI
//
//  Created by Tushar Patil on 22/05/24.
//

// cltr+cmd+spacebar for emoji

import Foundation

@MainActor
class CreatureDetailViewmodel: ObservableObject {
    
    
    private struct Returned: Codable {
        
        var height: Double?
        var weight: Double?
        var sprites: Sprite
    }
    
    struct Sprite: Codable {
        var front_default: String?
        var other: Other
    }
    
    struct Other: Codable {
        var officalArtwork: OfficialArtwork
        
        enum CodingKeys: String, CodingKey {
            case officalArtwork = "official-artwork"
            
        }
    }
    
    struct OfficialArtwork: Codable {
        var front_default: String?
    }
    
    var urlString = ""
    @Published var height = 0.0
    @Published var weight = 0.0
    @Published var imageURL = ""
    
    func getData() async {
        
        
        print("🕸 We are accessing the url \(urlString)")
        
        
        //Create a  URL
        
        guard let url = URL(string: urlString) else
        {
            print("👿 Error: Could not create a URL from \(urlString)")
            return
        }
        
        
        do {
            
            let (data, response) =  try await URLSession.shared.data(from: url)
            
            
            guard let returned = try? JSONDecoder().decode(Returned.self, from: data) else {
                
                print("👿 JSON Error: Could not decode returned JSON data")
                
                return
            }
            self.height = returned.height ?? 0.0
            self.weight = returned.weight ?? 0.0
            self.imageURL = returned.sprites.other.officalArtwork.front_default ?? "n/a"
            
            
        } catch {
            
            print("👿 Error: Could not user URL at \(urlString) to get data and response ")
            
        }
        
        
    }
}
