import SwiftUI

struct DetailView: View {
    
    @StateObject var creatureDetailVM = CreatureDetailViewmodel()
    @State private var animateCard = false
    
    var creature: Creature
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(creature.name.capitalized)
                .font(Font.custom("Avenir Next Condensed", size: 60))
                .bold()
                .minimumScaleFactor(0.5)
                .lineLimit(1)
                .padding(.bottom, 20)
            
            ZStack {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(alignment: .center, spacing: 20) {
                        creatureImage
                        
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(alignment: .top) {
                                Text("Height:")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.red)
                                
                                Text(String(format: "%.1f", creatureDetailVM.height))
                                    .font(.title2)
                                    .bold()
                            }
                            
                            HStack(alignment: .top) {
                                Text("Weight:")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.red)
                                
                                Text(String(format: "%.1f", creatureDetailVM.weight))
                                    .font(.title2)
                                    .bold()
                            }
                            
                            
                        }
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(16)
                .shadow(radius: 8, x: 5, y: 5)
                .scaleEffect(animateCard ? 1.0 : 0.8)
                .opacity(animateCard ? 1.0 : 0.0)
                .animation(.easeInOut(duration: 0.5), value: animateCard)
            }
            
            Spacer()
        }
        .padding()
        .onAppear {
            animateCard = true
        }
        .task {
            creatureDetailVM.urlString = creature.url
            await creatureDetailVM.getData()
        }
    }
}

extension DetailView {
    
    var creatureImage: some View {
        AsyncImage(url: URL(string: creatureDetailVM.imageURL)) { phase in
            if let image = phase.image { // we have a valid image
                image
                    .resizable()
                    .scaledToFit()
                    .background(Color.white)
                    .frame(width: 150, height: 150)
                    .cornerRadius(16)
                    .shadow(radius: 8, x: 5, y: 5)
                    .overlay {
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                    }
            } else if phase.error != nil { // we have an error
                Image(systemName: "questionmark.square.dashed")
                    .resizable()
                    .scaledToFit()
                    .background(Color.white)
                    .frame(width: 150, height: 150)
                    .cornerRadius(16)
                    .shadow(radius: 8, x: 5, y: 5)
                    .overlay {
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                    }
            } else { // use a placeholder
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 150, height: 150)
            }
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(creature: Creature(name: "bulbasur", url: "https://pokeapi.co/api/v2/pokemon/1/"))
    }
}
