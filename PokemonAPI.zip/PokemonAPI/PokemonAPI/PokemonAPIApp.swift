//
//  PokemonAPIApp.swift
//  PokemonAPI
//
//  Created by Tushar Patil on 22/05/24.
//

import SwiftUI

@main
struct PokemonAPIApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
            CreaturesListView()
        }
    }
}
