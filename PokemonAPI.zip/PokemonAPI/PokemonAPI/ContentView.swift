//
//  ContentView.swift
//  PokemonAPI
//
//  Created by Tushar Patil on 22/05/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


